# 2 nd Person Identification > 2024-10-02 11:38pm
https://universe.roboflow.com/my-first-model/2-nd-person-identification

Provided by a Roboflow user
License: CC BY 4.0

