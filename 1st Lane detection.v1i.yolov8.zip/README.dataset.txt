# 1st Lane detection > 2024-08-15 5:51pm
https://universe.roboflow.com/my-first-model/1st-lane-detection

Provided by a Roboflow user
License: CC BY 4.0

